"""Attach a PyTorch-Lightning CSVLogger to OpenFold3 training runs.

OpenFold3 only attaches a logger when wandb is configured, so a plain
`run_openfold train` produces no metrics file at all -- the loss only
scrolls past on stdout. Putting this directory on PYTHONPATH makes Python
import it automatically (sitecustomize), and every Lightning Trainer that
was created without a logger gets a CSVLogger writing one row per step.

Usage:
    export PYTHONPATH=/path/to/of3_csvlogger_hook:$PYTHONPATH
    export OF3_METRICS_DIR=outputs/my_run          # optional; default ./result
    pixi run -e openfold3-cuda13 run_openfold train --runner-yaml <cfg>.yaml

Output:
    <OF3_METRICS_DIR>/metrics/version_0/metrics.csv
    (falls back to the Trainer's default_root_dir, then to ./result --
     i.e. a 'result' folder created in the directory you launch from)

The csv has one row per logged step with every metric OpenFold3 logs
(train/loss, train/diffusion_loss, train/distogram_loss, ...).
"""
import os
import sys

# Helper processes (multiprocessing resource_tracker, semaphore cleaners, ...)
# start as `python -c ...`. Importing torch there is pointless and can chain
# into runaway process spawning, so bail out early.
_IS_HELPER = (not sys.argv) or sys.argv[0] in ("-c", "")

if not _IS_HELPER:
    try:
        import pytorch_lightning as pl
        from pytorch_lightning.loggers import CSVLogger


        import time

        class _StepTimeCallback(pl.Callback):
            def __init__(self):
                self._last = None

            def on_train_batch_start(self, trainer, *args, **kwargs):
                self._last = time.monotonic()

            def on_train_batch_end(self, trainer, pl_module, *args, **kwargs):
                if self._last is not None:
                    pl_module.log(
                        "train/step_wall_seconds",
                        time.monotonic() - self._last,
                        on_step=True,
                        on_epoch=False,
                        prog_bar=False,
                        logger=True,
                    )


        class _OptimStateCallback(pl.Callback):
            """Per-step grad norm; every 25 steps Adam m/v norms, EMA
            distance, and a parameter checksum proxy (sum of |theta|)."""

            def on_before_optimizer_step(self, trainer, pl_module, optimizer):
                import torch as _torch
                grads = [
                    param.grad
                    for group in optimizer.param_groups
                    for param in group["params"]
                    if param.grad is not None
                ]
                if not grads:
                    return
                with _torch.no_grad():
                    norms = _torch._foreach_norm(grads)
                    total = _torch.linalg.vector_norm(
                        _torch.stack(norms)
                    ).item()
                pl_module.log(
                    "train/grad_norm", total,
                    on_step=True, on_epoch=False, logger=True,
                )

            def on_train_batch_end(self, trainer, pl_module, *args, **kwargs):
                step = trainer.global_step
                if step % 50 != 0:
                    return
                import torch as _torch
                with _torch.no_grad():
                    m_sq = v_sq = p_abs = ema_d = 0.0
                    optimizers = trainer.optimizers
                    if optimizers:
                        state = optimizers[0].state
                        for param, slot in state.items():
                            if "exp_avg" in slot:
                                m_sq += float(
                                    slot["exp_avg"].float().pow(2).sum()
                                )
                            if "exp_avg_sq" in slot:
                                v_sq += float(
                                    slot["exp_avg_sq"].float().abs().sum()
                                )
                    ema_params = None
                    ema = getattr(pl_module, "ema", None)
                    if ema is not None:
                        ema_state = getattr(ema, "params", None) or getattr(
                            ema, "shadow_params", None
                        )
                        if isinstance(ema_state, dict):
                            ema_params = ema_state
                    named = dict(pl_module.named_parameters())
                    for name, param in named.items():
                        value = param.detach().float()
                        p_abs += float(value.abs().sum())
                        if ema_params is not None and name in ema_params:
                            ema_d += float(
                                (value - ema_params[name].float())
                                .pow(2).sum()
                            )
                    log = pl_module.log
                    log("train/adam_m_norm", m_sq ** 0.5,
                        on_step=True, on_epoch=False, logger=True)
                    log("train/adam_v_l1", v_sq,
                        on_step=True, on_epoch=False, logger=True)
                    log("train/param_abs_sum", p_abs,
                        on_step=True, on_epoch=False, logger=True)
                    if ema_params is not None:
                        log("train/ema_param_dist", ema_d ** 0.5,
                            on_step=True, on_epoch=False, logger=True)

        _original_init = pl.Trainer.__init__

        def _patched_init(self, *args, **kwargs):
            configured = kwargs.get("logger")
            if configured in (None, False) or configured == []:
                save_dir = (
                    os.environ.get("OF3_METRICS_DIR")
                    or kwargs.get("default_root_dir")
                    or "result"
                )
                kwargs["logger"] = CSVLogger(
                    save_dir=save_dir,
                    name="metrics",
                    # default is every 100 steps, which makes the file look
                    # empty while a short run is in flight
                    flush_logs_every_n_steps=1,
                )
                print(
                    f"[of3_csvlogger_hook] metrics -> {save_dir}/metrics/version_*/metrics.csv",
                    flush=True,
                )
            callbacks = kwargs.get("callbacks") or []
            if not isinstance(callbacks, list):
                callbacks = [callbacks]
            callbacks.append(_StepTimeCallback())
            if os.environ.get("OF3_OPTIM_METRICS") == "1":
                callbacks.append(_OptimStateCallback())
            kwargs["callbacks"] = callbacks
            return _original_init(self, *args, **kwargs)

        pl.Trainer.__init__ = _patched_init
    except Exception as error:  # never break training because of the hook
        print(f"[of3_csvlogger_hook] disabled: {error}", flush=True)
