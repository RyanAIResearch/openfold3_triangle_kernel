#!/usr/bin/env bash
# SR statistical campaign: 4 scratch blocks (order-balanced) + 1 pretrained
# block, per-step loss + wall time via the csvlogger hook, then chained
# capture batches for the delta-ladder matrix.
set -euo pipefail

ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
STATS=/home/ubuntu/xzz/of3_perf_runs/sr_pre400
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
WHEEL_ROOT="$BASE/wheel_env_a94b"
SR_ROOT=/home/ubuntu/xzz/of3_sr_dq
CUEQ_EXT="$BASE/torch_extensions_292"
SR_EXT="$BASE/torch_ext_srdq"
SCRATCH_CUEQ_YAML="$BASE/harness/e2e_abba_sr/a_cueq.yaml"
SCRATCH_SR_YAML="$BASE/harness/e2e_abba_sr/a_stable.yaml"
PRE_CFG=/home/ubuntu/xzz/of3_perf_runs/pretrained400_90e20081/configs
DRIVER=/tmp/claude-1000/-home-ubuntu-xzz/7e522781-b3b4-47bf-a008-e0fc688a239d/scratchpad/sr_capture_driver.py

mkdir -p "$STATS/configs"

make_cfg() {  # src arm outdir -> config path
  local src="$1" outdir="$2" epoch="$3" dst="$4"
  sed "s|  output_dir: .*|  output_dir: $outdir|; s|epoch_len: [0-9]*|epoch_len: $epoch|" \
    "$src" > "$dst"
}

run_arm() {  # name pypath extdir jit sr shadow config
  local name="$1" pypath="$2" extdir="$3" jit="$4" sr="$5" shadow="$6" config="$7"
  local outdir="$STATS/$name"
  mkdir -p "$outdir"
  date --iso-8601=seconds > "$outdir/wall.time"
  printf 'START %s %s\n' "$name" "$(date --iso-8601=seconds)"
  PATH="$ENV_ROOT/bin:$PATH" \
    PYTHONPATH="$HOOK:$pypath" \
    TORCH_EXTENSIONS_DIR="$extdir" \
    OPENFOLD3_TRIANGLE_ALLOW_JIT="$jit" \
    OPENFOLD3_SR_BACKWARD="$sr" \
    OPENFOLD3_SR_SHADOW="$shadow" \
    OF3_METRICS_DIR="$outdir/metrics" \
    /usr/bin/time -f 'wall_seconds=%e' -a -o "$outdir/wall.time" \
    "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$config" \
    > "$outdir/train.log" 2>&1
  date --iso-8601=seconds >> "$outdir/wall.time"
  printf 'END %s %s\n' "$name" "$(date --iso-8601=seconds)"
}

cueq_arm() {  # name config
  run_arm "$1" "$WHEEL_ROOT" "$CUEQ_EXT" 0 0 0 "$2"
}
sr_arm() {  # name config
  run_arm "$1" "$SR_ROOT" "$SR_EXT" 1 1 1 "$2"
}

cueq_arm p400_cueq "/home/ubuntu/xzz/of3_perf_runs/sr_pre400/configs/cueq.yaml"
sr_arm p400_sr "/home/ubuntu/xzz/of3_perf_runs/sr_pre400/configs/sr.yaml"
echo "PRE400_DONE"
