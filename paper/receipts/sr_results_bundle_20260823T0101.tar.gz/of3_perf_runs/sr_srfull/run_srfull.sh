#!/usr/bin/env bash
set -euo pipefail
ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
S=/home/ubuntu/xzz/of3_perf_runs/sr_srfull
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
SR_ROOT=/home/ubuntu/xzz/of3_sr_dq
while ! grep -q "FORK1000_DONE" /home/ubuntu/xzz/of3_perf_runs/sr_fork1000/driver.log 2>/dev/null; do sleep 180; done
run_sr() {
  local name="$1" config="$2"
  mkdir -p "$S/$name"
  date --iso-8601=seconds > "$S/$name/wall.time"
  printf 'START %s %s\n' "$name" "$(date --iso-8601=seconds)"
  PATH="$ENV_ROOT/bin:$PATH" PYTHONPATH="$HOOK:$SR_ROOT" \
    TORCH_EXTENSIONS_DIR="$BASE/torch_ext_srdq" \
    OPENFOLD3_TRIANGLE_ALLOW_JIT=1 OPENFOLD3_SR_BACKWARD=1 \
    OPENFOLD3_SR_SHADOW=1 OF3_OPTIM_METRICS=1 \
    OF3_METRICS_DIR="$S/$name/metrics" \
    /usr/bin/time -f 'wall_seconds=%e' -a -o "$S/$name/wall.time" \
    "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$config" \
    > "$S/$name/train.log" 2>&1
  printf 'END %s %s\n' "$name" "$(date --iso-8601=seconds)"
}
run_sr sr_prefix "$S/configs/sr_prefix.yaml"
SRCKPT=$(find $S/sr_prefix -name "last.ckpt" | head -1)
if [ -z "$SRCKPT" ]; then echo "NO_SR_CHECKPOINT"; exit 1; fi
sed "s|SRLASTCKPT|$SRCKPT|" $S/configs/sr_cont.yaml > $S/configs/sr_cont_final.yaml
run_sr sr_cont "$S/configs/sr_cont_final.yaml"
echo "SRFULL_DONE"
