#!/usr/bin/env bash
# SR statistical campaign: 4 scratch blocks (order-balanced) + 1 pretrained
# block, per-step loss + wall time via the csvlogger hook, then chained
# capture batches for the delta-ladder matrix.
set -euo pipefail

ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
STATS=/home/ubuntu/xzz/of3_perf_runs/sr_stats_blocks
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
WHEEL_ROOT="$BASE/wheel_env_a94b"
SR_ROOT=/home/ubuntu/xzz/of3_sr_dq
CUEQ_EXT="$BASE/torch_extensions_292"
SR_EXT="$BASE/torch_ext_srdq"
SCRATCH_CUEQ_YAML="$BASE/harness/e2e_abba_sr/a_cueq.yaml"
SCRATCH_SR_YAML="$BASE/harness/e2e_abba_sr/a_stable.yaml"
PRE_CFG=/home/ubuntu/xzz/of3_perf_runs/pretrained400_90e20081/configs
DRIVER=/tmp/claude-1000/-home-ubuntu-xzz/7e522781-b3b4-47bf-a008-e0fc688a239d/scratchpad/sr_capture_driver.py

mkdir -p "$STATS/configs"

make_cfg() {  # src arm outdir -> config path
  local src="$1" outdir="$2" epoch="$3" dst="$4"
  sed "s|  output_dir: .*|  output_dir: $outdir|; s|epoch_len: [0-9]*|epoch_len: $epoch|" \
    "$src" > "$dst"
}

run_arm() {  # name pypath extdir jit sr shadow config
  local name="$1" pypath="$2" extdir="$3" jit="$4" sr="$5" shadow="$6" config="$7"
  local outdir="$STATS/$name"
  mkdir -p "$outdir"
  date --iso-8601=seconds > "$outdir/wall.time"
  printf 'START %s %s\n' "$name" "$(date --iso-8601=seconds)"
  PATH="$ENV_ROOT/bin:$PATH" \
    PYTHONPATH="$HOOK:$pypath" \
    TORCH_EXTENSIONS_DIR="$extdir" \
    OPENFOLD3_TRIANGLE_ALLOW_JIT="$jit" \
    OPENFOLD3_SR_BACKWARD="$sr" \
    OPENFOLD3_SR_SHADOW="$shadow" \
    OF3_METRICS_DIR="$outdir/metrics" \
    /usr/bin/time -f 'wall_seconds=%e' -a -o "$outdir/wall.time" \
    "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$config" \
    > "$outdir/train.log" 2>&1
  date --iso-8601=seconds >> "$outdir/wall.time"
  printf 'END %s %s\n' "$name" "$(date --iso-8601=seconds)"
}

cueq_arm() {  # name config
  run_arm "$1" "$WHEEL_ROOT" "$CUEQ_EXT" 0 0 0 "$2"
}
sr_arm() {  # name config
  run_arm "$1" "$SR_ROOT" "$SR_EXT" 1 1 1 "$2"
}

# ---- scratch blocks, order-balanced: AB BA BA AB ----
for block in 1 2 3 4; do
  for arm in cueq sr; do
    src="$SCRATCH_CUEQ_YAML"; [ "$arm" = sr ] && src="$SCRATCH_SR_YAML"
    make_cfg "$src" "$STATS/b${block}_${arm}/run" 30 \
      "$STATS/configs/b${block}_${arm}.yaml"
  done
done
run_block_ab() { cueq_arm "b$1_cueq" "$STATS/configs/b$1_cueq.yaml"; sr_arm "b$1_sr" "$STATS/configs/b$1_sr.yaml"; }
run_block_ba() { sr_arm "b$1_sr" "$STATS/configs/b$1_sr.yaml"; cueq_arm "b$1_cueq" "$STATS/configs/b$1_cueq.yaml"; }
run_block_ab 1
run_block_ba 2
run_block_ba 3
run_block_ab 4

# ---- pretrained block (sharp-regime loss referee), order AB ----
make_cfg "$PRE_CFG/crop640_cueq.yaml" "$STATS/pre_cueq/run" 30 \
  "$STATS/configs/pre_cueq.yaml"
make_cfg "$PRE_CFG/crop640_stablefold.yaml" "$STATS/pre_sr/run" 30 \
  "$STATS/configs/pre_sr.yaml"
cueq_arm pre_cueq "$STATS/configs/pre_cueq.yaml"
sr_arm pre_sr "$STATS/configs/pre_sr.yaml"

# ---- chained capture batches for the delta-ladder matrix ----
CAPBASE=/home/ubuntu/xzz/of3_perf_runs
capture() {  # tag config skip
  PATH="$ENV_ROOT/bin:$PATH" \
    PYTHONPATH="$SR_ROOT" \
    TORCH_EXTENSIONS_DIR="$SR_EXT" \
    OPENFOLD3_TRIANGLE_ALLOW_JIT=1 \
    OPENFOLD3_SR_BACKWARD=1 \
    SR_CAPTURE_DIR="$CAPBASE/sr_capture_matrix/$1" \
    SR_CAPTURE_LIMIT=6 \
    SR_CAPTURE_SKIP="$3" \
    "$ENV_ROOT/bin/python" "$DRIVER" train --runner-yaml "$2" \
    > "$CAPBASE/sr_capture_matrix/$1.log" 2>&1 || true
}
mkdir -p "$CAPBASE/sr_capture_matrix"
make_cfg "$PRE_CFG/crop640_stablefold.yaml" "$CAPBASE/sr_capture_matrix/c640deep/run" 1 \
  "$STATS/configs/cap640_deep.yaml"
make_cfg "$PRE_CFG/crop384_stablefold.yaml" "$CAPBASE/sr_capture_matrix/c384/run" 1 \
  "$STATS/configs/cap384.yaml"
capture c640_skip20 "$STATS/configs/cap640_deep.yaml" 20
capture c640_skip60 "$STATS/configs/cap640_deep.yaml" 60
capture c384_skip0 "$STATS/configs/cap384.yaml" 0
echo "STATS_CAMPAIGN_DONE"
