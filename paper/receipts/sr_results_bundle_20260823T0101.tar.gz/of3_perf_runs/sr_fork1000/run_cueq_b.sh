#!/usr/bin/env bash
set -euo pipefail
ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
F=/home/ubuntu/xzz/of3_perf_runs/sr_fork1000
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
while ! grep -q "SRFULL_DONE" /home/ubuntu/xzz/of3_perf_runs/sr_srfull/driver.log 2>/dev/null; do sleep 300; done
mkdir -p "$F/fork_cueq_b"
date --iso-8601=seconds > "$F/fork_cueq_b/wall.time"
PATH="$ENV_ROOT/bin:$PATH" PYTHONPATH="$HOOK:$BASE/wheel_env_a94b" \
  TORCH_EXTENSIONS_DIR="$BASE/torch_extensions_292" \
  OPENFOLD3_TRIANGLE_ALLOW_JIT=0 OPENFOLD3_SR_BACKWARD=0 OPENFOLD3_SR_SHADOW=0 \
  OF3_OPTIM_METRICS=1 OF3_METRICS_DIR="$F/fork_cueq_b/metrics" \
  /usr/bin/time -f 'wall_seconds=%e' -a -o "$F/fork_cueq_b/wall.time" \
  "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$F/configs/fork_cueq_b.yaml" \
  > "$F/fork_cueq_b/train.log" 2>&1
echo "CUEQ_B_DONE"
