#!/usr/bin/env bash
set -euo pipefail
ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
F=/home/ubuntu/xzz/of3_perf_runs/sr_fork1000
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
WHEEL_ROOT="$BASE/wheel_env_a94b"
SR_ROOT=/home/ubuntu/xzz/of3_sr_dq
# wait for the p400 pair to release the GPU
while ! grep -q "PRE400_DONE" /home/ubuntu/xzz/of3_perf_runs/sr_pre400/driver.log 2>/dev/null; do sleep 120; done
run_arm() {
  local name="$1" pypath="$2" extdir="$3" jit="$4" sr="$5" config="$6"
  mkdir -p "$F/$name"
  date --iso-8601=seconds > "$F/$name/wall.time"
  printf 'START %s %s\n' "$name" "$(date --iso-8601=seconds)"
  PATH="$ENV_ROOT/bin:$PATH" PYTHONPATH="$HOOK:$pypath" \
    TORCH_EXTENSIONS_DIR="$extdir" OPENFOLD3_TRIANGLE_ALLOW_JIT="$jit" \
    OPENFOLD3_SR_BACKWARD="$sr" OPENFOLD3_SR_SHADOW="$sr" \
    OF3_OPTIM_METRICS=1 \
    OF3_METRICS_DIR="$F/$name/metrics" \
    /usr/bin/time -f 'wall_seconds=%e' -a -o "$F/$name/wall.time" \
    "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$config" \
    > "$F/$name/train.log" 2>&1
  printf 'END %s %s\n' "$name" "$(date --iso-8601=seconds)"
}
run_arm prefix_cueq "$WHEEL_ROOT" "$BASE/torch_extensions_292" 0 0 "$F/configs/prefix_cueq.yaml"
CKPT=$(find $F/prefix/run -name "last.ckpt" | head -1)
if [ -z "$CKPT" ]; then echo "NO_CHECKPOINT_FOUND"; exit 1; fi
echo "FORKING FROM $CKPT"
"$ENV_ROOT/bin/python" - <<VERIFY
import torch
ckpt = torch.load("$CKPT", map_location="cpu", weights_only=False)
print("CKPT KEYS:", sorted(ckpt.keys()))
print("global_step:", ckpt.get("global_step"))
print("has optimizer_states:", "optimizer_states" in ckpt)
print("has lr_schedulers:", "lr_schedulers" in ckpt)
VERIFY
sed "s|LASTCKPT|$CKPT|" $F/configs/fork_cueq.yaml > $F/configs/fork_cueq_final.yaml
sed "s|LASTCKPT|$CKPT|" $F/configs/fork_sr.yaml > $F/configs/fork_sr_final.yaml
run_arm fork_cueq "$WHEEL_ROOT" "$BASE/torch_extensions_292" 0 0 "$F/configs/fork_cueq_final.yaml"
run_arm fork_sr "$SR_ROOT" "$BASE/torch_ext_srdq" 1 1 "$F/configs/fork_sr_final.yaml"
echo "FORK1000_DONE"
