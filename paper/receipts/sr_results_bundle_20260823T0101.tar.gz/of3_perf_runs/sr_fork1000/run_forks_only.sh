#!/usr/bin/env bash
set -euo pipefail
ENV_ROOT=/home/ubuntu/xzz/openfold3_workspace/src/.pixi/envs/openfold3-cuda12
BASE=/home/ubuntu/xzz/of3_perf_runs/crop640_c527e41bc.XAkp3Y
F=/home/ubuntu/xzz/of3_perf_runs/sr_fork1000
HOOK=/home/ubuntu/xzz/of3_perf_runs/sr_stats_hook
SR_ROOT=/home/ubuntu/xzz/of3_sr_dq
CKPT=$F/prefix_cueq/metrics/metrics/version_0/checkpoints/last.ckpt
run_arm() {
  local name="$1" pypath="$2" extdir="$3" jit="$4" sr="$5" config="$6"
  mkdir -p "$F/$name"
  date --iso-8601=seconds > "$F/$name/wall.time"
  printf 'START %s %s\n' "$name" "$(date --iso-8601=seconds)"
  PATH="$ENV_ROOT/bin:$PATH" PYTHONPATH="$HOOK:$pypath" \
    TORCH_EXTENSIONS_DIR="$extdir" OPENFOLD3_TRIANGLE_ALLOW_JIT="$jit" \
    OPENFOLD3_SR_BACKWARD="$sr" OPENFOLD3_SR_SHADOW="$sr" \
    OF3_OPTIM_METRICS=1 \
    OF3_METRICS_DIR="$F/$name/metrics" \
    /usr/bin/time -f 'wall_seconds=%e' -a -o "$F/$name/wall.time" \
    "$ENV_ROOT/bin/run_openfold" train --runner-yaml "$config" \
    > "$F/$name/train.log" 2>&1
  printf 'END %s %s\n' "$name" "$(date --iso-8601=seconds)"
}
echo "FORKING FROM $CKPT"
sed "s|LASTCKPT|$CKPT|" $F/configs/fork_cueq.yaml > $F/configs/fork_cueq_final.yaml
sed "s|LASTCKPT|$CKPT|" $F/configs/fork_sr.yaml > $F/configs/fork_sr_final.yaml
run_arm fork_cueq "$BASE/wheel_env_a94b" "$BASE/torch_extensions_292" 0 0 "$F/configs/fork_cueq_final.yaml"
run_arm fork_sr "$SR_ROOT" "$BASE/torch_ext_srdq" 1 1 "$F/configs/fork_sr_final.yaml"
echo "FORK1000_DONE"
