"""Private AOT CUDA extension modules for TurboPairFormer kernels.

The binary modules are installed by the H100/H200 ``sm_90a`` wheel.  They are
kept in a private package so their CPython initializer names cannot collide
with the historical top-level modules created by ``cpp_extension.load``.
"""
