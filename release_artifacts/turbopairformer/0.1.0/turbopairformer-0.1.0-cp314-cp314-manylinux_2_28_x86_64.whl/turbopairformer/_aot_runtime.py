# SPDX-License-Identifier: Apache-2.0

"""Fail-closed loader for the AOT TurboPairFormer CUDA extensions.

Production always imports wheel-owned binary modules.  Runtime JIT
exists only for source-tree development and requires the explicit
``TURBOPAIRFORMER_ALLOW_JIT=1`` opt-in.  There is deliberately no automatic
fallback when an AOT artifact is absent or ABI-incompatible.
"""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import re
import sysconfig
from pathlib import Path
from threading import Lock
from typing import Any

import torch

from turbopairformer.policy import ALLOW_JIT, distributed_execution_flag

_DEVELOPMENT_JIT_ENV = "TURBOPAIRFORMER_ALLOW_JIT"
# Accepted for compatibility with OpenFold3 forks that predate the standalone
# package; the canonical name above takes precedence when both are set.
_LEGACY_DEVELOPMENT_JIT_ENV = "OPENFOLD3_TRIANGLE_ALLOW_JIT"
_MANIFEST_PATH = Path(__file__).with_name("_build_manifest.json")
_LOCK = Lock()
_MODULE_CACHE: dict[str, Any] = {}

_PRODUCTION_MODULE_CONTRACT: dict[str, tuple[str, tuple[str, ...]]] = {
    "stablefold_forward": (
        "turbopairformer._ext._stablefold_forward_sm90a",
        (
            "stablefold_triangle_forward_out",
            "stablefold_pack_qkv",
            "stablefold_triangle_forward_shadow_out",
        ),
    ),
    "stablefold_delta": (
        "turbopairformer._ext._stablefold_delta_sm90a",
        (
            "stablefold_triangle_delta_out",
            "stablefold_triangle_delta_shadow_out",
        ),
    ),
    "stablefold_dkdv": (
        "turbopairformer._ext._stablefold_dkdv_sm90a",
        (
            "stablefold_triangle_dkdv_out",
            "stablefold_triangle_dkdv_delta_true_out",
        ),
    ),
    "stablefold_dq_dbias": (
        "turbopairformer._ext._stablefold_dq_dbias_sm90a",
        (
            "stablefold_triangle_dq_dbias_out",
            "stablefold_reduce_broadcast_dbias_out",
            "stablefold_triangle_sr_backward_out",
        ),
    ),
    "stablefold_trimul": (
        "turbopairformer._ext._stablefold_trimul_sm90a",
        (
            "trimul_in_fwd",
            "trimul_out_fwd",
            "trimul_gate_split_bwd",
            "sig_mul_bwd_out",
            "ln_bwd_dx",
            "ln_bwd_dgb",
            "transpose_ln_bwd",
            "trimul_wgrad_fixed_fold",
        ),
    ),
}


class AOTExtensionError(RuntimeError):
    """Raised when the production AOT extension contract is not satisfied."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _manifest_path() -> Path:
    """Use an ignored editable receipt only inside a source package project.

    Installed wheels always read their embedded receipt.  Editable builds keep
    their generated receipt separate from the tracked source placeholder.
    """
    project = _MANIFEST_PATH.parent.parent
    local = _MANIFEST_PATH.with_name("_build_manifest.local.json")
    if (
        (project / "setup.py").is_file()
        and (project / "pyproject.toml").is_file()
        and local.is_file()
    ):
        return local
    return _MANIFEST_PATH


def _manifest() -> dict[str, Any]:
    path = _manifest_path()
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as error:
        raise AOTExtensionError(
            f"invalid AOT build manifest at {path}"
        ) from error
    if value.get("schema_version") != 1:
        raise AOTExtensionError("unsupported AOT build-manifest schema")
    return value


def _development_jit_enabled() -> bool:
    return distributed_execution_flag(ALLOW_JIT)


def _runtime_abi() -> dict[str, Any]:
    return {
        "python_soabi": sysconfig.get_config_var("SOABI"),
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "torch_cxx11_abi": bool(torch._C._GLIBCXX_USE_CXX11_ABI),
    }


def _preflight_aot_artifact(module_key: str, aot_module: str) -> Path:
    """Validate the wheel-owned binary before its initializer can execute."""

    manifest = _manifest()
    if not manifest.get("built"):
        raise AOTExtensionError(
            "the installed package contains a source-tree manifest rather than "
            "an AOT build manifest"
        )
    if manifest.get("target", {}).get("cuda_arch") != "sm_90a":
        raise AOTExtensionError("the extension wheel is not an sm_90a artifact")

    expected_abi = manifest.get("abi", {})
    actual_abi = _runtime_abi()
    mismatches = {
        name: (expected_abi.get(name), actual)
        for name, actual in actual_abi.items()
        if expected_abi.get(name) != actual
    }
    if mismatches:
        raise AOTExtensionError(f"AOT extension ABI mismatch: {mismatches}")

    if not torch.cuda.is_available():
        raise AOTExtensionError("the sm_90a extension requires an available CUDA GPU")
    capability = torch.cuda.get_device_capability(torch.cuda.current_device())
    if capability != (9, 0):
        raise AOTExtensionError(
            f"the sm_90a extension requires compute capability 9.0, got {capability}"
        )

    extension = manifest.get("extensions", {}).get(module_key)
    if not isinstance(extension, dict):
        raise AOTExtensionError(f"manifest has no extension entry for {module_key}")
    if extension.get("module") != aot_module:
        raise AOTExtensionError(f"manifest module mismatch for {module_key}")
    try:
        spec = importlib.util.find_spec(aot_module)
    except (ImportError, AttributeError, ValueError) as error:
        raise AOTExtensionError(f"cannot locate AOT module {aot_module}") from error
    if spec is None or spec.origin is None:
        raise AOTExtensionError(f"cannot locate AOT module {aot_module}")
    module_path = Path(spec.origin).resolve()
    expected_filename = Path(str(extension.get("filename", ""))).name
    if module_path.name != expected_filename:
        raise AOTExtensionError(f"binary filename mismatch for {module_key}")
    expected_hash = extension.get("sha256")
    if not expected_hash or _sha256(module_path) != expected_hash:
        raise AOTExtensionError(f"binary hash mismatch for {module_key}")
    return module_path


def _validate_loaded_aot_module(
    module_key: str,
    module: Any,
    expected_symbols: tuple[str, ...],
    preflight_path: Path,
) -> None:
    """Validate symbols and ensure import did not resolve a different file."""

    if Path(module.__file__).resolve() != preflight_path:
        raise AOTExtensionError(f"loaded binary path changed for {module_key}")
    missing = [name for name in expected_symbols if not hasattr(module, name)]
    if missing:
        raise AOTExtensionError(
            f"AOT extension {module_key} is missing symbols: {missing}"
        )


def _load_development_jit(
    *,
    module_key: str,
    source: Path,
    verbose: bool,
) -> Any:
    if not source.is_file():
        raise AOTExtensionError(f"development CUDA source is missing: {source}")
    if not torch.cuda.is_available():
        raise AOTExtensionError("development JIT requires an available CUDA GPU")
    capability = torch.cuda.get_device_capability(torch.cuda.current_device())
    if capability != (9, 0):
        raise AOTExtensionError(
            f"development JIT requires compute capability 9.0, got {capability}"
        )
    # Importing the compiler path is intentionally inside the explicit opt-in
    # branch.  Production import never touches cpp_extension or a build cache.
    from torch.utils.cpp_extension import load

    # The kernels use warpgroup MMA, which ptxas only accepts for the
    # arch-specific sm_90a target; plain "9.0" builds fail to assemble.
    os.environ.setdefault("TORCH_CUDA_ARCH_LIST", "9.0a")
    source_hash = _sha256(source)[:12]
    return load(
        name=f"turbopairformer_dev_{module_key}_{source_hash}",
        sources=[str(source)],
        extra_cuda_cflags=["-O3", "-lineinfo"],
        verbose=verbose,
    )


def load_extension_module(
    *,
    module_key: str,
    aot_module: str,
    source: Path,
    expected_symbols: tuple[str, ...],
    verbose: bool = False,
) -> Any:
    """Load one AOT module, with an explicit source-development escape hatch."""

    with _LOCK:
        cached = _MODULE_CACHE.get(module_key)
        if cached is not None:
            return cached
        try:
            artifact_path = _preflight_aot_artifact(module_key, aot_module)
            module = importlib.import_module(aot_module)
            _validate_loaded_aot_module(
                module_key, module, expected_symbols, artifact_path
            )
        except (ImportError, OSError, AOTExtensionError) as error:
            if not _development_jit_enabled():
                raise AOTExtensionError(
                    f"unable to load production AOT extension {aot_module}; install "
                    "the Python 3.14 / Torch 2.10 / CUDA 12.8 sm_90a wheel. "
                    "Source-tree developers may explicitly set "
                    f"{_DEVELOPMENT_JIT_ENV}=1. Cause: {error}"
                ) from error
            module = _load_development_jit(
                module_key=module_key,
                source=source,
                verbose=verbose,
            )
            missing = [name for name in expected_symbols if not hasattr(module, name)]
            if missing:
                raise AOTExtensionError(
                    f"development JIT module is missing symbols: {missing}"
                ) from error
        _MODULE_CACHE[module_key] = module
        return module


def distributed_aot_identity(module_keys: tuple[str, ...]) -> dict[str, Any]:
    """Preload and identify AOT modules before a distributed train step.

    Every rank calls this function independently and then exchanges the returned
    JSON-compatible identity.  Local failures are expected to be caught by the
    distributed contract so all ranks can leave together instead of one rank
    failing lazily while its peers wait in a later collective.
    """

    if _development_jit_enabled():
        raise AOTExtensionError(
            "distributed production training forbids development JIT"
        )

    manifest = _manifest()
    git = manifest.get("git", {})
    if (
        git.get("dirty") is not False
        or re.fullmatch(r"[0-9a-f]{40}", str(git.get("commit", ""))) is None
    ):
        raise AOTExtensionError("distributed AOT manifest must attest dirty=false")
    target = manifest.get("target", {})
    if target.get("cuda_arch") != "sm_90a" or target.get("ptx_embedded") is not False:
        raise AOTExtensionError(
            "distributed production requires sm_90a SASS with no embedded PTX"
        )

    requested = tuple(sorted(set(module_keys)))
    unknown = [key for key in requested if key not in _PRODUCTION_MODULE_CONTRACT]
    if unknown:
        raise AOTExtensionError(f"unknown distributed AOT modules: {unknown}")

    install_root = Path(__file__).resolve().parents[1]
    packaged_sources: dict[str, str] = {}
    for relative, expected_hash in sorted(manifest.get("sources", {}).items()):
        if not relative.startswith("turbopairformer/"):
            continue
        source_path = install_root / relative
        if not source_path.is_file() or _sha256(source_path) != expected_hash:
            raise AOTExtensionError(
                f"packaged source does not match AOT manifest: {relative}"
            )
        packaged_sources[relative] = expected_hash
    if not packaged_sources:
        raise AOTExtensionError(
            "distributed AOT manifest has no verifiable packaged sources"
        )

    extensions: dict[str, dict[str, Any]] = {}
    with _LOCK:
        for module_key in requested:
            aot_module, expected_symbols = _PRODUCTION_MODULE_CONTRACT[module_key]
            artifact_path = _preflight_aot_artifact(module_key, aot_module)
            module = importlib.import_module(aot_module)
            _validate_loaded_aot_module(
                module_key, module, expected_symbols, artifact_path
            )
            _MODULE_CACHE[module_key] = module
            extensions[module_key] = {
                "filename": artifact_path.name,
                "module": aot_module,
                "sha256": _sha256(artifact_path),
                "symbols": list(expected_symbols),
            }

    return {
        "schema_version": 1,
        "manifest_sha256": _sha256(_manifest_path()),
        "git": git,
        "target": target,
        "abi": manifest.get("abi"),
        "packaged_source_sha256": packaged_sources,
        "extensions": extensions,
    }


def source_sha256_for(module_key: str, source: Path) -> dict[str, str]:
    """Return the source digest embedded in the AOT artifact receipt."""

    manifest = _manifest()
    sources = manifest.get("sources", {})
    recorded = sources.get(source.name)
    if not isinstance(recorded, str):
        matches = [
            digest
            for relative, digest in sources.items()
            if relative.endswith("/" + source.name)
        ]
        recorded = matches[0] if len(matches) == 1 else None
    if isinstance(recorded, str):
        return {source.name: recorded}
    if source.is_file():
        return {source.name: _sha256(source)}
    raise AOTExtensionError(
        f"no recorded source hash for {module_key}; install an AOT wheel or "
        f"set {_DEVELOPMENT_JIT_ENV}=1 in a source checkout"
    )


__all__ = [
    "AOTExtensionError",
    "distributed_aot_identity",
    "load_extension_module",
    "source_sha256_for",
]
